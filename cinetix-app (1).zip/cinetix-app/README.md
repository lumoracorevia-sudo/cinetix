# Cinetix — deploy this to go live

## What's in here
A working Next.js app: signup/login (email + password), onboarding, the AI
generator (script + scaled image prompts), the 2-free-per-day gate, and the
$2 / 10-day paywall linking to your Whop checkout.

## Step 1 — Push this to GitHub
1. Create a new repository on github.com (e.g. `cinetix`)
2. Upload all these files into it (GitHub lets you drag-and-drop files in
   the web UI if you don't want to use git commands)

## Step 2 — Import into Vercel
1. Go to vercel.com, click **Add New > Project**
2. Choose **Import** next to the `cinetix` repo you just created
3. Before clicking Deploy, open **Environment Variables** and add these four:

```
SUPABASE_URL = https://zbrbyxcwjlkryreweoqt.supabase.co
SUPABASE_SERVICE_ROLE_KEY = (your Supabase service_role key)
GEMINI_API_KEY = (your Gemini API key)
WHOP_WEBHOOK_SECRET = (see step 3 below)
```

4. Click **Deploy**. Vercel gives you a live URL like `cinetix.vercel.app`
   when it's done (takes about a minute).

## Step 3 — Connect the Whop webhook
1. In your Whop dashboard, find **Webhooks** (usually under Developer or
   Settings)
2. Add a new webhook pointing to:
   `https://your-vercel-url.vercel.app/api/webhooks/whop`
3. Whop will show you a signing secret when you create it — copy that and
   paste it into Vercel's `WHOP_WEBHOOK_SECRET` environment variable, then
   redeploy (Vercel > Deployments > click the three dots > Redeploy)

## Step 4 — Test it
1. Visit your live URL, sign up with a real email, do the onboarding
2. Generate twice, confirm the paywall shows on the 3rd try
3. Pay the $2 yourself once to confirm the webhook flips your account to
   premium in Supabase (check the `user_access` table — `has_premium_pass`
   should become `true`)

## Notes
- Whop's exact webhook payload field names can change — if the webhook
  doesn't work on first try, check https://dev.whop.com/webhooks and let
  me know what the actual payload looks like so I can adjust the route.
- The Gemini free tier has daily/per-minute limits — if generations start
  failing under load, that's why. See the earlier spreadsheet for details.
