import { supabase } from "../../../lib/supabase";
import bcrypt from "bcryptjs";

export async function POST(req) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return Response.json(
        { error: "invalid_input", message: "Email and password are required" },
        { status: 400 }
      );
    }

    const { data: user, error } = await supabase
      .from("user_access")
      .select("email, password_hash, name, niche, has_premium_pass, pass_expires_at")
      .eq("email", email)
      .maybeSingle();

    if (error || !user) {
      return Response.json(
        { error: "invalid_credentials", message: "Incorrect email or password" },
        { status: 401 }
      );
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return Response.json(
        { error: "invalid_credentials", message: "Incorrect email or password" },
        { status: 401 }
      );
    }

    return Response.json({
      success: true,
      email: user.email,
      name: user.name,
      niche: user.niche,
      hasPremium:
        user.has_premium_pass &&
        user.pass_expires_at &&
        new Date(user.pass_expires_at) > new Date(),
    });
  } catch (err) {
    return Response.json({ error: "server_error", message: err.message }, { status: 500 });
  }
}
